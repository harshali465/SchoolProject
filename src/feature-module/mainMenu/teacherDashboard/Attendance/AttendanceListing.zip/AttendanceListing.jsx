import { useContext, useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { MdClose, MdSignalCellularNull } from "react-icons/md";

import { Checkbox, notification, Table, DatePicker } from "antd";
import {
  Modal,
  Box,
  IconButton,
  Button,
  Typography,
  Select,
  MenuItem,
} from "@mui/material";

import { all_routes } from "../../../router/all_routes";
import { TimePicker } from "antd";

import {
  CModal,
  CButton,
  CModalHeader,
  CModalTitle,
  CModalBody,
  CModalFooter,
} from "@coreui/react";
import axios from "axios";
import CommonSelect from "../../../../core/common/commonSelect";
import dayjs from "dayjs";
import { AuthContext } from "../../../helper/AuthState";
import moment from "moment";
const AttendanceListingteacher = () => {
  const [filterDateRange, setFilterDateRange] = useState("");
  const [ownAttendance, setownAttendance] = useState(false);
  const [assistantteaches, setassistantteaches] = useState([]);
  const academicYearId = localStorage.getItem("academicYearId");
  const [allStages, setAllStages] = useState([]);
  const [stages, setStages] = useState("");
  const [grades, setGrades] = useState("");
  const [section, setSection] = useState("");
  const [allGrades, setAllGrades] = useState([]);
  const [allSections, setAllSections] = useState([]);
  const [open, setOpen] = useState(true);
  const [selectedClass, setSelectedClass] = useState(false);
  const [token] = useState(localStorage.getItem("accessToken"));
  const { authState } = useContext(AuthContext);
  const [selectedSlot, setSelectedSlot] = useState(null);
  const [alluser, setUserList] = useState("");
  const [visible, setVisible] = useState(false);
  const [dateRanges, setDateRanges] = useState([]);
  const [selectedDate, setSelectedDate] = useState(null);

  const navigate = useNavigate();

  const [loading, setLoading] = useState(false);

  const [alloption, setslotoption] = useState([]);
  const [slots, setSlots] = useState("");

  const redirectto = () => {
    navigate("/student/attendance/certificates");
  };

  const getStages = async () => {
    try {
      const res = await axios.get(
        `${process.env.REACT_APP_DEV_BASE_URL}/api/v1/stage-grade-section/stage`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      if (res?.status === 200) {
        setAllStages(res?.data?.records);
      }
    } catch (error) {
      console.error("Error fetching stages:", error);
    }
  };

  const getWorkingDayId = async () => {
    try {
      const res = await axios.get(
        `${
          process.env.REACT_APP_DEV_BASE_URL
        }/api/v1/academics/working-day?stageId=${stages}&academicYearId=${
          academicYearId == authState?.startYearId
            ? academicYearId
            : authState?.startYearId
        }`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      console.log("this isa a res", res);
      setDateRanges(res?.data?.data);
    } catch (error) {
      console.error("Error fetching stages:", error);
    }
  };

  useEffect(() => {
    if (stages) {
      getWorkingDayId();
    }
  }, [stages]);

  useEffect(() => {
    getStages();
  }, []);
  const getUsers = async () => {
    try {
      const response = await axios.get(
        `${process.env.REACT_APP_DEV_BASE_URL}/api/v1/stage-grade-section/get-student-by-grade-section?gradeId=${grades}&sectionId=${section}`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      const dataWithSelection = response?.data?.data.map((item) => ({
        ...item,
        selected: true,
      }));
      setUserList(dataWithSelection);
    } catch (error) {
      console.error("Error fetching users:", error);
      setUserList([]);
    }
  };

  const getTimeTableList = async () => {
    setLoading(true);
    try {
      const response = await axios.get(
        `${
          process.env.REACT_APP_DEV_BASE_URL
        }/api/v1/time-table/teacher/${localStorage.getItem(
          "userId"
        )}?workingDaysId=${filterDateRange}&day=${dayjs().format(
          "dddd"
        )}&date=${dayjs().format("YYYY-MM-DD")}&gradeId=${
          grades ? grades : ""
        }&sectionId=${section ? section : ""}&academicYearId=${
          academicYearId == authState?.startYearId
            ? academicYearId
            : authState?.startYearId
        }`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      setSlots(response?.data?.data?.[0]?.timeTable?.[0]?.slots);
    } catch (error) {
      console.error("Error fetching users:", error);
      setLoading(false);
    }
  };

  useEffect(() => {
    if (slots) {
      const slotOptions = slots.map((slot) => ({
        value: slot._id,
        label: `${slot.startTime} - ${slot.endTime}`,
        subject: slot.subjectId,
        assistantTeacher1: slot?.asstTeacherId1 ? slot?.asstTeacherId1 : null,
        assistantTeacher2: slot?.asstTeacherId2 ? slot?.asstTeacherId2 : null,
      }));

      setslotoption(slotOptions);
    }
  }, [slots]);
  useEffect(() => {
    if (selectedSlot) setSelectedClass(true);
  }, [selectedSlot]);
  useEffect(() => {
    if (filterDateRange) {
      getTimeTableList();
      getUsers();
    }
  }, [filterDateRange]);

  const getGrades = async (id) => {
    try {
      const res = await axios.get(
        `${process.env.REACT_APP_DEV_BASE_URL}/api/v1/stage-grade-section/stage/${id}/grade`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      setAllGrades(res?.data?.records);
    } catch (error) {
      console.log(error);
    }
  };

  const getSections = async (sid, id) => {
    try {
      const res = await axios.get(
        `${process.env.REACT_APP_DEV_BASE_URL}/api/v1/stage-grade-section/stage/${stages}/grade/${sid}/section`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      setAllSections(res?.data?.records);
    } catch (error) {
      console.log(error);
    }
  };

  const handleMarkAttendance = (data) => {
    setassistantteaches([...assistantteaches, { asstTeacherId: data._id }]);
    setVisible(false);
  };

  const handleSelect = (id) => {
    setUserList((prevData) =>
      prevData.map((record) =>
        record._id === id ? { ...record, selected: !record.selected } : record
      )
    );
  };

  const columns = [
    {
      title: "S.No.",
      dataIndex: "index",
      key: "index",
      width: 0,
      render: (_, __, index) => index + 1, // Calculates serial number
    },
    {
      title: "Student Name",
      width: 100,
      render: (_, render) => render?.firstName,
    },
    {
      title: "Check",
      dataIndex: "selected",
      width: 50,
      render: (_, record) => (
        <Checkbox
          disabled={record?.leaveRequests.length !== 0}
          checked={record.selected}
          onChange={() => handleSelect(record?._id)}
        />
      ),
    },
  ];

  const [startTime, setStartTime] = useState(null);
  const [endTime, setEndTime] = useState(null);
  const handleClassSelect = () => {
    // if (selectedClass) {
    setOpen(false); // Close modal when class is selected
    // }
  };
  const [assistant, setAssistant] = useState("");

  const markAttendance = async (e) => {
    e.preventDefault();
    if (!selectedSlot) {
      notification.warning({
        message: "Warning",
        description: "Plese select the slot for marking the attendance  !",
      });
      return;
    }
    if (!ownAttendance) {
      notification.warning({
        message: "Warning",
        description: "Plese mark your own attendance first !",
      });
      return;
    }
    try {
      const response = await axios.post(
        `${process.env.REACT_APP_DEV_BASE_URL}/api/v1/attendance/class-attendance`,

        {
          teacherId: ownAttendance && localStorage.getItem("userId"),
          gradeId: grades,
          sectionId: section,
          assistantTeachers: assistantteaches,
          students: alluser
            .filter(
              (data) =>
                data.selected === true && data.leaveRequests.length === 0
            )
            .map((data) => ({ studentId: data._id })),
          date: moment().format("YYYY-MM-DD"),
          startTime: selectedSlot
            ? selectedSlot?.label?.split("-")[0].trim()
            : "",
          endTime: selectedSlot
            ? selectedSlot?.label?.split("-")[1].trim()
            : "",
          subjectId: selectedSlot?.subject?._id,
          academicYearId:
            academicYearId == authState?.startYearId
              ? academicYearId
              : authState?.startYearId,
        },

        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      notification.success({
        message: "sucess",
        description: " Attendance Marked  Successfully",
      });
    } catch (error) {
      notification.error({
        message: "Error",
        description: "Failed to assign ",
      });
    }
  };

  // Call the function (you can trigger this on a button click or similar)
  // markAttendance();
  const [inputValue, setInputValue] = useState("");
  return (
    <div>
      <>
        <CModal
          backdrop="static"
          visible={visible}
          onClose={() => setVisible(false)}
          aria-labelledby="StaticBackdropExampleLabel"
        >
          <CModalHeader>
            <CModalTitle id="StaticBackdropExampleLabel">
              Mark Attendance
            </CModalTitle>
          </CModalHeader>
          <CModalBody className="pb-3">
            Are you sure you want to mark the attendance as present?
          </CModalBody>
          <CModalFooter className="pl-0">
            <CButton color="secondary" onClick={() => setVisible(false)}>
              Close
            </CButton>
            <CButton
              color="primary"
              className="ms-2"
              onClick={() => {
                if (assistant === "Teacher") {
                  setownAttendance(true);
                  setVisible(false);
                } else {
                  handleMarkAttendance(assistant);
                  setVisible(false);
                }
              }}
            >
              Yes!
            </CButton>
          </CModalFooter>
        </CModal>
        {/* /teacher/attendance/leavelisting */}
        {/* <Modal open={open} onClose={() => setOpen(true)}>
          <Box
            sx={{
              position: "absolute",
              top: "50%",
              left: "50%",
              transform: "translate(-50%, -50%)",
              width: 300,
              bgcolor: "white",
              boxShadow: 24,
              p: 3,
              borderRadius: 2,
              textAlign: "center",
            }}
          >
             <IconButton
      onClick={() => setOpen(false)}
      sx={{
        position: "absolute",
        top: 8,
        right: 8,
      }}
    >
      <MdClose />
    </IconButton>
            <div className="mb-3 flex-fill flex-1">
              <label
                className="form-label font-size-seperate"
                style={{
                  display: "block",
                  fontSize: "13px !important",
                  textAlign: "start",
                }}
              >
                Stage
              </label>

              <CommonSelect
                className="select"
                options={allStages?.map((cat) => ({
                  value: cat._id,
                  label: cat.stage,
                }))}
                value={
                  stages
                    ? {
                        value: stages,
                        label: allStages.find((cat) => cat._id === stages)
                          ?.stage,
                      }
                    : null
                }
                onChange={(e) => {
                  setStages(e ? e.value : null);
                  getGrades(e.value);
                }}
              />
            </div>

            <div className="mb-3 flex-fill flex-1">
              <label
                className="form-label  font-size-seperate"
                style={{
                  display: "block",
                  fontSize: "13px !important",
                  textAlign: "start",
                }}
              >
                Grade
              </label>

              <CommonSelect
                className="select"
                options={allGrades?.map((cat) => ({
                  value: cat._id,
                  label: cat.grade,
                }))}
                value={
                  grades
                    ? {
                        value: grades,
                        label: allGrades.find((cat) => cat._id === grades)
                          ?.grade,
                      }
                    : null
                }
                onChange={(e) => {
                  setGrades(e ? e.value : null);
                  getSections(e.value);
                }}
              />
            </div>
            <div className="mb-3 flex-fill flex-1">
              <label
                className="form-label  font-size-seperate"
                style={{
                  display: "block",
                  fontSize: "13px !important",
                  textAlign: "start",
                }}
              >
                Section
              </label>

              <CommonSelect
                className="select"
                options={allSections?.map((cat) => ({
                  value: cat._id,
                  label: cat.section,
                }))}
                value={
                  section
                    ? {
                        value: section,
                        label: allSections.find((cat) => cat._id === section)
                          ?.section,
                      }
                    : null
                }
                onChange={(e) => setSection(e.value)}
              />
            </div>

            <div className="mb-3 flex-fill flex-1">
              <label
                className="form-label  font-size-seperate"
                style={{
                  display: "block",
                  fontSize: "13px !important",
                  textAlign: "start",
                }}
              >
                Slot
              </label>

              <CommonSelect
                className="select"
                options={alloption}
                value={
                  selectedSlot
                    ? {
                        value: selectedSlot.value,
                        label:
                          alloption.find(
                            (opt) => opt.value === selectedSlot.value
                          )?.label || "",
                      }
                    : null
                }
                onChange={(e) => {
                  setSelectedSlot(e ? e : null);
                }}
              />
            </div>

            <button
              className="btn btn-primary"
              sx={{ mt: 2 }}
              onClick={handleClassSelect}
              disabled={!selectedClass}
            >
              Enter
            </button>
          </Box>
        </Modal> */}

        {/* Page Wrapper */}
        <div className="page-wrapper">
          <div className="content">
            {/* Page Header */}
            <div className="d-md-flex d-block align-items-center justify-content-between mb-3">
              <div className="my-auto mb-2">
                <h3 className="text-dark" style={{ fontSize: "x-large" }}>
                  Mark Attendance For Current Lecture
                </h3>
              </div>
              <div className="button-box">
                <div className="d-flex my-xl-auto right-content align-items-center flex-wrap">
                  <div className="mb-2 big-button">
                    <Link
                      className="btn btn-primary big-button"
                      to={all_routes.teacher.TodayAttendance}
                    >
                      <i class="ti ti-calendar-search me-2"></i>
                      View Today Attendance
                    </Link>
                  </div>
                </div>
                <div className="d-flex my-xl-auto right-content align-items-center flex-wrap">
                  <div className="mb-2 big-button">
                    <Link
                      className="btn btn-primary big-button "
                      to={all_routes.teacher.UpdateTodayAttendance}
                    >
                      <i class="ti ti-edit me-2"></i>
                      Update past Attendance
                    </Link>
                  </div>
                </div>
              </div>
            </div>
            <div className="attendance-box">
              <div className="d-flex flex-column  width-res">
                <div
                  className="d-flex gap-5 mb-3
"
                >
                  {/* justify-content-between                    */}

                  <div
                    className="d-flex align-items-center"
                    style={{ width: "100%" }}
                  >
                    <button
                      className={`btn ${
                        ownAttendance ? "btn-success" : "btn-success-light"
                      }  big-button mb-2`}
                      onClick={() => {
                        setVisible(true);
                        setAssistant("Teacher");
                      }}
                    >
                      Mark Own Attendance
                    </button>
                  </div>
                  {(selectedSlot?.assistantTeacher1 ||
                    selectedSlot?.assistantTeacher2) && (
                    <div
                      className="card p-2 d-flex flex-row align-items-center gap-2 justify-content-center  desktop-show"
                      style={{ marginBottom: "0px" }}
                    >
                      <h5 className="text-center">Assistent teacher</h5>
                      <div className="d-flex gap-2 justify-content-between align-items-center px-3">
                        <span className="ml-2">
                          {selectedSlot?.assistantTeacher1.firstName}{" "}
                          {selectedSlot?.assistantTeacher1.lastName}
                        </span>
                        <button
                          className={`btn ${
                            assistantteaches.length > 0 &&
                            assistantteaches.every(
                              (data) =>
                                data?.asstTeacherId ===
                                selectedSlot?.assistantTeacher1?._id
                            )
                              ? "btn-success"
                              : "btn-success-light"
                          } `}
                          onClick={() => {
                            setVisible(true);
                            setAssistant(selectedSlot?.assistantTeacher1);
                          }}
                        >
                          Mark present
                        </button>
                      </div>
                      {selectedSlot?.assistantTeacher2 && (
                        <div className="d-flex justify-content-between gap-2 align-items-center px-3">
                          <span className="ml-2">
                            {selectedSlot?.assistantTeacher2?.firstName}{" "}
                            {selectedSlot?.assistantTeacher2?.lastName}
                          </span>
                          <button
                            className={`btn ${
                              assistantteaches.length > 0 &&
                              assistantteaches.every(
                                (data) =>
                                  data?.asstTeacherId ===
                                  selectedSlot?.assistantTeacher2?._id
                              )
                                ? "btn-success"
                                : "btn-success-light"
                            } `}
                            onClick={() => {
                              setVisible(true);
                              setAssistant(selectedSlot?.assistantTeacher2);
                            }}
                          >
                            Mark present
                          </button>
                        </div>
                      )}
                    </div>
                  )}
                </div>

                <div className="card p-3 desktop-show">
                  <div className="d-flex gap-2 justify-content-between">
                    {/* <div className="div-forcontent">
                        <h5>Date :</h5>
                        <h5 className="text-center">
                          {dayjs().format("DD-MM-YYYY")}
                        </h5>
                      </div>
                      <div className="div-forcontent">
                        <h5>Start Time :</h5>
                        <h5 className="text-center">
                          {selectedSlot
                            ? selectedSlot?.label?.split("-")[0]
                            : ""}
                        </h5>
                      </div>
                      <div className="div-forcontent">
                        <h5>End Time :</h5>
                        <h5 className="text-center">
                          {selectedSlot
                            ? selectedSlot?.label?.split("-")[1]
                            : ""}
                        </h5>
                      </div>
                      <div className="div-forcontent">
                        <h5>Subject :</h5>
                        <h5 className="text-center ">
                          {selectedSlot ? selectedSlot?.subject?.subject : ""}
                        </h5>
                      </div> */}

                    <div className="mb-3 flex-fill flex-1">
                      <label
                        className="form-label font-size-seperate"
                        style={{
                          display: "block",
                          fontSize: "13px !important",
                          textAlign: "start",
                        }}
                      >
                        Stage
                      </label>

                      <CommonSelect
                        className="select"
                        options={allStages?.map((cat) => ({
                          value: cat._id,
                          label: cat.stage,
                        }))}
                        value={
                          stages
                            ? {
                                value: stages,
                                label: allStages.find(
                                  (cat) => cat._id === stages
                                )?.stage,
                              }
                            : null
                        }
                        onChange={(e) => {
                          setStages(e ? e.value : null);
                          getGrades(e.value);
                        }}
                      />
                    </div>

                    <div className="mb-3 flex-fill flex-1">
                      <label
                        className="form-label  font-size-seperate"
                        style={{
                          display: "block",
                          fontSize: "13px !important",
                          textAlign: "start",
                        }}
                      >
                        Grade
                      </label>

                      <CommonSelect
                        className="select"
                        options={allGrades?.map((cat) => ({
                          value: cat._id,
                          label: cat.grade,
                        }))}
                        value={
                          grades
                            ? {
                                value: grades,
                                label: allGrades.find(
                                  (cat) => cat._id === grades
                                )?.grade,
                              }
                            : null
                        }
                        onChange={(e) => {
                          setGrades(e ? e.value : null);
                          getSections(e.value);
                        }}
                      />
                    </div>
                    <div className="mb-3 flex-fill flex-1">
                      <label
                        className="form-label  font-size-seperate"
                        style={{
                          display: "block",
                          fontSize: "13px !important",
                          textAlign: "start",
                        }}
                      >
                        Section
                      </label>

                      <CommonSelect
                        className="select"
                        options={allSections?.map((cat) => ({
                          value: cat._id,
                          label: cat.section,
                        }))}
                        value={
                          section
                            ? {
                                value: section,
                                label: allSections.find(
                                  (cat) => cat._id === section
                                )?.section,
                              }
                            : null
                        }
                        onChange={(e) => setSection(e.value)}
                      />
                    </div>

                    <div className="mb-3 flex-fill flex-1">
                      <label
                        className="form-label  font-size-seperate"
                        style={{
                          display: "block",
                          fontSize: "13px !important",
                          textAlign: "start",
                        }}
                      >
                        Working Day
                      </label>

                      <select
                        value={filterDateRange}
                        onChange={(e) => {
                          setFilterDateRange(e.target.value);
                          console.log("Selected Date Range:", e.target.value);
                        }}
                        className="form-control form-select"
                      >
                        <option value="">Select Date Range</option>
                        {dateRanges?.map((res, i) => (
                          <option value={res?._id} key={i}>
                            {moment(res.start_date).format("DD-MM-YYYY")} -{" "}
                            {moment(res.end_date).format("DD-MM-YYYY")}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div className="mb-3 flex-fill flex-1">
                      <label
                        className="form-label  font-size-seperate"
                        style={{
                          display: "block",
                          fontSize: "13px !important",
                          textAlign: "start",
                        }}
                      >
                        Slot
                      </label>

                      <CommonSelect
                        className="select"
                        options={alloption}
                        value={
                          selectedSlot
                            ? {
                                value: selectedSlot.value,
                                label:
                                  alloption.find(
                                    (opt) => opt.value === selectedSlot.value
                                  )?.label || "",
                              }
                            : null
                        }
                        onChange={(e) => {
                          setSelectedSlot(e ? e : null);
                          setInputValue(e.subject.subject);
                        }}
                      />
                    </div>
                    <div className="mb-3 flex-fill flex-1">
                      <label
                        className="form-label  font-size-seperate"
                        style={{
                          display: "block",
                          fontSize: "13px !important",
                          textAlign: "start",
                        }}
                      >
                        Date
                      </label>
                      <DatePicker
                        className="form-control datetimepicker"
                        format={{
                          format: "DD-MM-YYYY",
                          type: "mask",
                        }}
                        disabled
                        value={moment()}
                        placeholder="Select Date"
                      />
                    </div>
                    <div className="mb-3 flex-fill flex-1">
                      <label
                        className="form-label  font-size-seperate"
                        style={{
                          display: "block",
                          fontSize: "13px !important",
                          textAlign: "start",
                        }}
                      >
                        Subject
                      </label>
                      <input
                        type="text"
                        className="text-center input"
                        style={{
                          borderRadius: "5px",
                          border: "1px solid #d9d9d9",
                          padding: "8px 0px",
                        }}
                        value={
                          selectedSlot ? selectedSlot.subject?.subject : ""
                        }
                        disabled
                      />
                    </div>
                  </div>
                </div>
              </div>
              {(selectedSlot?.assistantTeacher1 ||
                selectedSlot?.assistantTeacher2) && (
                <div className="card p-2 d-flex flex-column gap-2 justify-content-center mobile-show">
                  <h5 className="text-center mb-1">Assistent teacher</h5>
                  <div className="d-flex gap-2 justify-content-between align-items-center px-3">
                    <span className="ml-2">
                      {selectedSlot?.assistantTeacher1.firstName}{" "}
                      {selectedSlot?.assistantTeacher1.lastName}
                    </span>
                    <button
                      className={`btn ${
                        assistantteaches.length > 0 &&
                        assistantteaches.every(
                          (data) =>
                            data?.asstTeacherId ===
                            selectedSlot?.assistantTeacher1?._id
                        )
                          ? "btn-success"
                          : "btn-success-light"
                      } `}
                      onClick={() => {
                        setVisible(true);
                        setAssistant(selectedSlot?.assistantTeacher1);
                      }}
                    >
                      Mark present
                    </button>
                  </div>
                  {selectedSlot?.assistantTeacher2 && (
                    <div className="d-flex justify-content-between gap-2 align-items-center px-3">
                      <span className="ml-2">
                        {selectedSlot?.assistantTeacher2?.firstName}{" "}
                        {selectedSlot?.assistantTeacher2?.lastName}
                      </span>
                      <button
                        className={`btn ${
                          assistantteaches.length > 0 &&
                          assistantteaches.every(
                            (data) =>
                              data?.asstTeacherId ===
                              selectedSlot?.assistantTeacher2?._id
                          )
                            ? "btn-success"
                            : "btn-success-light"
                        } `}
                        onClick={() => {
                          setVisible(true);
                          setAssistant(selectedSlot?.assistantTeacher2);
                        }}
                      >
                        Mark present
                      </button>
                    </div>
                  )}
                </div>
              )}
            </div>

            <div className="card p-3 mobile-show">
              {/* <div className="d-flex card p-2 flex-column gap-2">
                <h5 className="text-center">
                  Date : {dayjs().format("DD-MM-YYYY")}
                </h5>
              </div>
              <div className="d-flex card p-2 flex-column gap-2">
                <h5 className="text-center">
                  Period :{" "}
                  {selectedSlot ? selectedSlot?.label?.split("-")[0] : ""} -{" "}
                  {selectedSlot ? selectedSlot?.label?.split("-")[1] : ""}
                </h5>
              </div>
              <div className="d-flex card p-2 flex-column gap-2">
                <h5 className="text-center ">
                  Subject Name :{" "}
                  {selectedSlot ? selectedSlot?.subject?.subject : ""}
                </h5>
              </div> */}

              <div className="mb-3 flex-fill flex-1">
                <label
                  className="form-label font-size-seperate"
                  style={{
                    display: "block",
                    fontSize: "13px !important",
                    textAlign: "start",
                  }}
                >
                  Stage
                </label>

                <CommonSelect
                  className="select"
                  options={allStages?.map((cat) => ({
                    value: cat._id,
                    label: cat.stage,
                  }))}
                  value={
                    stages
                      ? {
                          value: stages,
                          label: allStages.find((cat) => cat._id === stages)
                            ?.stage,
                        }
                      : null
                  }
                  onChange={(e) => {
                    setStages(e ? e.value : null);
                    setAllGrades([]);
                    getGrades(e.value);
                  }}
                />
              </div>

              <div className="mb-3 flex-fill flex-1">
                <label
                  className="form-label  font-size-seperate"
                  style={{
                    display: "block",
                    fontSize: "13px !important",
                    textAlign: "start",
                  }}
                >
                  Grade
                </label>

                <CommonSelect
                  className="select"
                  options={allGrades?.map((cat) => ({
                    value: cat._id,
                    label: cat.grade,
                  }))}
                  value={
                    grades
                      ? {
                          value: grades,
                          label: allGrades.find((cat) => cat._id === grades)
                            ?.grade,
                        }
                      : null
                  }
                  onChange={(e) => {
                    setGrades(e ? e.value : null);
                    setAllSections([]);
                    getSections(e.value);
                  }}
                />
              </div>
              <div className="mb-3 flex-fill flex-1">
                <label
                  className="form-label  font-size-seperate"
                  style={{
                    display: "block",
                    fontSize: "13px !important",
                    textAlign: "start",
                  }}
                >
                  Section
                </label>

                <CommonSelect
                  className="select"
                  options={allSections?.map((cat) => ({
                    value: cat._id,
                    label: cat.section,
                  }))}
                  value={
                    section
                      ? {
                          value: section,
                          label: allSections.find((cat) => cat._id === section)
                            ?.section,
                        }
                      : null
                  }
                  onChange={(e) => setSection(e.value)}
                />
              </div>

              <div className="mb-3 flex-fill flex-1">
                <label
                  className="form-label  font-size-seperate"
                  style={{
                    display: "block",
                    fontSize: "13px !important",
                    textAlign: "start",
                  }}
                >
                  Working Day
                </label>

                <CommonSelect
                  className="select"
                  options={
                    dateRanges?.map((res) => ({
                      value: res?._id,
                      label: `${moment(res.start_date).format(
                        "DD-MM-YYYY"
                      )} - ${moment(res.end_date).format("DD-MM-YYYY")}`,
                    })) || []
                  }
                  value={
                    filterDateRange
                      ? {
                          value: filterDateRange,
                          label: dateRanges.find(
                            (res) => res._id === filterDateRange
                          )
                            ? `${moment(
                                dateRanges.find(
                                  (res) => res._id === filterDateRange
                                )?.start_date
                              ).format("DD-MM-YYYY")} - ${moment(
                                dateRanges.find(
                                  (res) => res._id === filterDateRange
                                )?.end_date
                              ).format("DD-MM-YYYY")}`
                            : "",
                        }
                      : null
                  }
                  onChange={(selectedOption) => {
                    setFilterDateRange(
                      selectedOption ? selectedOption.value : ""
                    );
                    console.log("Selected Date Range:", selectedOption);
                  }}
                />
              </div>

              <div className="mb-3 flex-fill flex-1">
                <label
                  className="form-label  font-size-seperate"
                  style={{
                    display: "block",
                    fontSize: "13px !important",
                    textAlign: "start",
                  }}
                >
                  Slot
                </label>

                <CommonSelect
                  className="select"
                  options={alloption}
                  value={
                    selectedSlot
                      ? {
                          value: selectedSlot.value,
                          label:
                            alloption.find(
                              (opt) => opt.value === selectedSlot.value
                            )?.label || "",
                        }
                      : null
                  }
                  onChange={(e) => {
                    setSelectedSlot(e ? e : null);
                    setInputValue(e.subject.subject);
                  }}
                />
              </div>

              <div className="mb-3 flex-fill flex-1">
                <label
                  className="form-label  font-size-seperate"
                  style={{
                    display: "block",
                    fontSize: "13px !important",
                    textAlign: "start",
                  }}
                >
                  Date
                </label>
                <DatePicker
                  className="form-control datetimepicker"
                  format={{
                    format: "DD-MM-YYYY",
                    type: "mask",
                  }}
                  disabled
                  value={moment()}
                  placeholder="Select Date"
                />
              </div>
              <div className="mb-3 flex-fill flex-1">
                <label
                  className="form-label  font-size-seperate"
                  style={{
                    display: "block",
                    fontSize: "13px !important",
                    textAlign: "start",
                  }}
                >
                  Subject
                </label>
                <input
                  type="text"
                  className="text-center input"
                  style={{
                    borderRadius: "5px",
                    border: "1px solid #d9d9d9",
                    padding: "8px 0px",
                  }}
                  value={inputValue}
                  disabled
                />

                <button
                  className="btn btn-light"
                  style={{ marginLeft: "5px" }}
                  onClick={() => {
                    setStages({ value: "", label: "" });
                    setGrades({ value: "", label: "" });
                    setSection({ value: "", label: "" });
                    setDateRanges({ value: "", label: "" });

                    setInputValue("");
                    setSelectedSlot([]);
                    setAllGrades([]);
                    setAllSections([]);
                    setslotoption([]);
                  }}
                >
                  Reset
                </button>
              </div>
            </div>

            <div className="card mt-5">
              <Table
                rowKey="_id"
                columns={columns}
                width={300}
                className="bordered-table width-box"
                dataSource={alluser}
                pagination={false}
              />
            </div>

            <div className="d-flex justify-content-center mb-5">
              <button
                className="btn btn-primary"
                onClick={(e) => markAttendance(e)}
              >
                Present
              </button>
            </div>
          </div>
        </div>
      </>
    </div>
  );
};

export default AttendanceListingteacher;
